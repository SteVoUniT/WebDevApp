import React, { useState } from "react";
import {
  AppBar,
  Toolbar,
  Typography,
  IconButton,
  Box,
  TextField,
  InputAdornment,
  List,
  ListItem,
  ListItemAvatar,
  Avatar,
  ListItemText,
  Paper,
  Button,
} from "@mui/material";

import MenuIcon from "@mui/icons-material/Menu";
import NotificationsIcon from "@mui/icons-material/Notifications";
import SearchIcon from "@mui/icons-material/Search";
import PersonIcon from "@mui/icons-material/Person";

const MessagingCenter: React.FC = () => {
  // State to store the list of messages
  const [messages, setMessages] = useState([
    { id: 1, name: "Nikolai", lastMessageTime: "3:07pm" },
    { id: 2, name: "Elizabeth", lastMessageTime: "3:07pm" },
    { id: 3, name: "Shannon", lastMessageTime: "3:07pm" },
    { id: 4, name: "Steven", lastMessageTime: "3:07pm" },
    { id: 5, name: "Christian", lastMessageTime: "3:07pm" },
    { id: 6, name: "Tom", lastMessageTime: "3:07pm" },
  ]);

  // Function to add a new message dynamically
  const addMessage = () => {
    const newMessage = {
      id: messages.length + 1, // Assign a new unique ID
      name: `User ${messages.length + 1}`,
      lastMessageTime: new Date().toLocaleTimeString(), // Use current time
    };
    setMessages([...messages, newMessage]); // Update state with new message
  };

  return (
    <Box
      sx={{
        maxWidth: 480,
        mx: "auto",
        bgcolor: "#000",
        minHeight: "100vh",
        color: "#fff",
      }}
    >
      {/* Navigation Bar */}
      <AppBar position="static" sx={{ bgcolor: "#000" }}>
        <Toolbar>
          <IconButton edge="start" color="inherit">
            <MenuIcon />
          </IconButton>
          <Typography variant="h6" sx={{ mx: 2 }}>
            Civicom
          </Typography>
          <Typography variant="h6" sx={{ flexGrow: 1 }}>
            Messaging Center
          </Typography>
          <IconButton edge="end" color="inherit">
            <NotificationsIcon />
          </IconButton>
        </Toolbar>
      </AppBar>

      {/* Search Bar */}
      <Box sx={{ textAlign: "center", p: 2 }}>
        <TextField
          variant="outlined"
          placeholder="Search Bar"
          sx={{
            width: "80%",
            maxWidth: 300,
            bgcolor: "#fff",
            borderRadius: "25px",
          }}
          InputProps={{
            startAdornment: (
              <InputAdornment position="start">
                <SearchIcon />
              </InputAdornment>
            ),
          }}
        />
      </Box>

      {/* Message List Section */}
      <Box
        sx={{
          bgcolor: "#1496f3",
          borderTopLeftRadius: 40,
          borderTopRightRadius: 40,
          p: 2,
          pt: 4,
          minHeight: "calc(100vh - 120px)",
        }}
      >
        <List sx={{ mb: 2 }}>
          {messages.map((msg) => (
            <Paper
              key={msg.id}
              sx={{
                mb: 1,
                backgroundColor: "#d8e6ff",
                borderRadius: 1,
              }}
            >
              <ListItem>
                <ListItemAvatar>
                  <Avatar sx={{ bgcolor: "#a2cfff" }}>
                    <PersonIcon sx={{ color: "#fff" }} />
                  </Avatar>
                </ListItemAvatar>
                <ListItemText
                  primary={
                    <Typography
                      component="span"
                      variant="subtitle1"
                      sx={{ fontWeight: "bold" }}
                    >
                      {msg.name}
                    </Typography>
                  }
                  secondary={`Last Message: ${msg.lastMessageTime}`}
                />
              </ListItem>
            </Paper>
          ))}
        </List>

        {/* Button to add a new message */}
        <Box sx={{ textAlign: "center", mt: 2 }}>
          <Button variant="contained" color="primary" onClick={addMessage}>
            Add Message
          </Button>
        </Box>
      </Box>
    </Box>
  );
};

export default MessagingCenter;
