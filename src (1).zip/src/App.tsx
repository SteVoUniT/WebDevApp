import React from "react";
import MessagingCenter from "./MessagingCenter";

function App() {
  return <MessagingCenter />;
}

export default App;
